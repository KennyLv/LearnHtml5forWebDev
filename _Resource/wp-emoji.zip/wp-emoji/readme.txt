=== Plugin Name ===
Contributors: bolo1988
Donate link: http://appdp.com/
Tags: Emoji, iPhone, iPad
Requires at least: 3.0
Tested up to: 3.0
Stable tag: 1.1

在你的博客里显示 Emoji 表情。Display Apple Emoji fonts(SoftBank) on your WordPress blog.

== Description ==

在你的博客里显示 Emoji 表情。安装了这个插件以后，在写文章或评论时输入的 Emoji 字符可以转换成图片在页面上显示出来，非 Mac OS和iOS 用户也能看见。

本插件已经在中国领先的 iPhone/iPad App推荐网站 http://appdp.com/ 部署。

== Installation ==

1. 解压后把 `wp-emoji` 目录上传到 /wp-content/plugins
1. 在后台激活 `WP-Emoji` 插件
1. 到 `WP-Emoji 设置` 页面对本插件进行设置

== Frequently Asked Questions ==

= 怎么输入 Emoji 字符？ =
iPhone/iPad 用户可以使用表情键盘直接输入，Mac OS 10.7(Lion) 或更新版本用户可以使用系统自带的特殊字符面板进行输入。其他系统的用户暂时不能输入。

== Screenshots ==

1. 插件效果

== Changelog ==

= 1.2 =
* Fixed bug : can't appear emoji in comments
= 1.1 =
* Internationalize
= 1.0 =
* Released

== Upgrade Notice ==

None
