import React from 'react';
import ReactDOM from 'react-dom';
import Homepage from './components/Homepage';

ReactDOM.render(<Homepage />, document.getElementById('content'));

